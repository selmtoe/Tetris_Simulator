use simulator_cold_clear_wasm::{
    cc_add_next_piece, cc_begin_decision, cc_commit, cc_create, cc_destroy, cc_node_count,
    cc_suggest, cc_think, CcMove,
};

#[test]
fn reference_core_can_search_and_commit() {
    let board = [0u8; 400];
    let next = *b"IOLJSZTI";
    let weights = br#"{"back_to_back":52,"height":-39}"#;
    let bot = unsafe {
        cc_create(
            board.as_ptr(),
            b'T',
            next.as_ptr(),
            next.len() as u32,
            0,
            1,
            0,
            -1,
            2000,
            weights.as_ptr(),
            weights.len() as u32,
        )
    };
    assert!(!bot.is_null());
    let decision_limit = unsafe { cc_begin_decision(bot, 300, 0) };
    let nodes = unsafe { cc_think(bot, 32) };
    assert!(nodes > 1, "reference DAG did not expand: {}", nodes);
    assert!(decision_limit >= 301);

    let mut result = CcMove::default();
    assert_eq!(unsafe { cc_suggest(bot, 0, &mut result) }, 1);
    assert!(b"IOTLJSZ".contains(&result.piece));
    assert!(result.x >= 0 && result.x < 10);
    assert!(result.y >= 0 && result.y < 40);
    assert!(result.controller_inputs > 0);
    assert!(unsafe { cc_commit(bot) } != 0);
    assert!(unsafe { cc_add_next_piece(bot, b'Z') } != 0);
    let retained = unsafe { cc_node_count(bot) };
    let next_limit = unsafe { cc_begin_decision(bot, 300, 0) };
    assert_eq!(next_limit, retained.saturating_add(300));
    let after = unsafe { cc_think(bot, 1) };
    assert!(after > retained, "retained decision added no work");
    unsafe { cc_destroy(bot) };
}

#[test]
fn decision_limits_accept_training_and_production_budgets() {
    let board = [0u8; 400];
    let next = *b"IOLJSZTI";
    let bot = unsafe {
        cc_create(
            board.as_ptr(),
            b'T',
            next.as_ptr(),
            next.len() as u32,
            0,
            1,
            0,
            -1,
            120_000,
            std::ptr::null(),
            0,
        )
    };
    assert!(!bot.is_null());
    for budget in [300, 10_000, 120_000] {
        let retained = unsafe { cc_node_count(bot) };
        assert_eq!(
            unsafe { cc_begin_decision(bot, budget, 7) },
            retained.saturating_add(budget)
        );
    }
    unsafe { cc_destroy(bot) };
}

#[cfg(feature = "deterministic-search")]
#[test]
fn identical_seed_contract_repeats_the_candidate_move() {
    unsafe fn make_fixture() -> *mut simulator_cold_clear_wasm::CcBot {
        let board = [0u8; 400];
        let next = *b"IOLJSZTI";
        cc_create(
            board.as_ptr(),
            b'T',
            next.as_ptr(),
            next.len() as u32,
            0,
            1,
            0,
            -1,
            10_000,
            std::ptr::null(),
            0,
        )
    }

    let first = unsafe { make_fixture() };
    let second = unsafe { make_fixture() };
    assert!(!first.is_null() && !second.is_null());

    let mut first_move = CcMove::default();
    unsafe {
        cc_begin_decision(first, 10_000, 7);
        cc_think(first, 256);
        assert_eq!(cc_suggest(first, 7, &mut first_move), 1);
    }
    let mut second_move = CcMove::default();
    unsafe {
        cc_begin_decision(second, 10_000, 7);
        cc_think(second, 256);
        assert_eq!(cc_suggest(second, 7, &mut second_move), 1);
    }

    assert_eq!(first_move.piece, second_move.piece);
    assert_eq!(first_move.hold, second_move.hold);
    assert_eq!(first_move.rotation, second_move.rotation);
    assert_eq!((first_move.x, first_move.y), (second_move.x, second_move.y));
    assert_eq!(first_move.movement_count, second_move.movement_count);
    assert_eq!(first_move.movements, second_move.movements);
    assert_eq!(first_move.nodes, second_move.nodes);
    assert_eq!(first_move.depth, second_move.depth);

    unsafe {
        cc_destroy(first);
        cc_destroy(second);
    }
}
