$ErrorActionPreference = 'Stop'
$labRoot = $PSScriptRoot
$repoRoot = Split-Path $labRoot -Parent
$crateManifest = Join-Path $repoRoot 'simulator/cold-clear-wasm/Cargo.toml'
& cargo build --manifest-path $crateManifest --release --target wasm32-unknown-unknown --features deterministic-search --locked
if ($LASTEXITCODE -ne 0) { throw 'Cold Clear build failed' }
$labBuild = Join-Path $labRoot 'build'
New-Item -ItemType Directory -Path $labBuild -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $repoRoot 'simulator/cold-clear-wasm/target/wasm32-unknown-unknown/release/simulator_cold_clear_wasm.wasm') -Destination (Join-Path $labBuild 'cold-clear.wasm')
Write-Output 'Built ai-lab/build/cold-clear.wasm'
& python (Join-Path $repoRoot 'tools/package-ai-licenses.py') --component cold-clear-ga
if ($LASTEXITCODE -ne 0) { throw 'GA source/license packaging failed' }
